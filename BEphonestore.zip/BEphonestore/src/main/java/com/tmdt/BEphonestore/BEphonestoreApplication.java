package com.tmdt.BEphonestore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BEphonestoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(BEphonestoreApplication.class, args);
	}

}
