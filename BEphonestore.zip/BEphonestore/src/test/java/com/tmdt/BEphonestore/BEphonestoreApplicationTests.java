package com.tmdt.BEphonestore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BEphonestoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
